CREATE TABLE Operador(
Cedula_NIT NUMBER(38),
direccion VARCHAR(1000) NOT NULL,
HorarioApertura NUMBER(38),
HorarioCierre NUMBER(38),
nombre VARCHAR(1000) NOT NULL,
PRIMARY KEY(Cedula_NIT)
);