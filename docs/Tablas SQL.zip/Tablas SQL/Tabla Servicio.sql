CREATE TABLE Servicio(
descripcion VARCHAR(1000),
idServicio NUMBER(38),
nombre VARCHAR(1000) NOT NULL,
PRIMARY KEY(idServicio)
);