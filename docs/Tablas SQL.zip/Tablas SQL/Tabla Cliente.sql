CREATE TABLE Cliente(
cedula NUMBER(38),
nombre VARCHAR(1000) NOT NULL,
rolUniandino VARCHAR(1000),
PRIMARY KEY(cedula)
);