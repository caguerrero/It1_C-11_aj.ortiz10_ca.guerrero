CREATE TABLE Reserva(
fechaReserva DATE NOT NULL,
finEstadia DATE NOT NULL,
idReserva NUMBER(38),
inicioEstadia DATE NOT NULL,
precio NUMBER(38) NOT NULL,
idCliente NUMBER(38),
idOfertaAlojamiento NUMBER(38),
PRIMARY KEY(idReserva),
FOREIGN KEY(idCliente) REFERENCES Cliente(cedula),
FOREIGN KEY(idOfertaAlojamiento) REFERENCES OfertaAlojamiento(idOfertaAlojamiento)
);