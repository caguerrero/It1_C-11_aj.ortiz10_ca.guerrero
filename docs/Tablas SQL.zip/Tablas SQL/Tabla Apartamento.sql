CREATE TABLE Apartamento(
idApartamento NUMBER(38),
menaje VARCHAR(1000) NOT NULL,
numHabitaciones NUMBER(38) NOT NULL,
PRIMARY KEY(idApartamento),
FOREIGN KEY (idApartamento)REFERENCES OfertaAlojamiento(idOfertaAlojamiento)
);