CREATE TABLE Habitacion(
idHabitacion NUMBER(38),
categoria VARCHAR(1000),
compartido VARCHAR(1000) NOT NULL,
tipo VARCHAR(1000),
PRIMARY KEY(idHabitacion),
FOREIGN KEY (idHabitacion)REFERENCES OfertaAlojamiento(idOfertaAlojamiento)
);