CREATE TABLE ServiciosDeAlojamiento(
idServicio NUMBER(38),
idOfertaAlojamiento NUMBER(38),
PRIMARY KEY(idServicio,idOfertaAlojamiento),
FOREIGN KEY (idServicio) REFERENCES Servicio(idServicio),
FOREIGN KEY (idOfertaAlojamiento) REFERENCES OfertaAlojamiento(idOfertaAlojamiento)
);